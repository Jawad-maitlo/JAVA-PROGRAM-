#include <iostream>
#include <cstdlib>
#include <ctime>
#include <conio.h>

using namespace std;



// Function to clear the screen
void clearScreen() {
#ifdef _WIN32
    system("cls"); //window
#else
    system("clear"); //linux
#endif
}

// Function to display the game title
void displayTitle() {
    //cout << "\033[1;33m"; // yellow
    cout << "====================================================" << endl;
    cout << "                  GAME OF HEART                     " << endl;
    cout << "====================================================" << endl;
    //cout << "\033[0m";
}

// Function to display the game rules
void displayRules() {
   // cout << "\033[3;32m"; // green
    cout << "=================== GAME RULES =====================" << endl;
    cout << "1. Each player spins and gets a random number (1-6)." << endl;
    cout << "2. The average of all spins (rounded up) + 1 is calculated." << endl;
    cout << "3. If a player's number matches the average, they win the round." << endl;
    cout << "4. Players lose 1 point for not matching the average." << endl;
    cout << "5. Players are eliminated when their points reach -6." << endl;
    cout<<  "6. There may be more than one winner in a around if more than one player's point matches target"<<endl;
    cout<<  "7. There may no winner in a around if player's point doesn't matches target"<<endl;
    cout<<  "8. In such around where there is no waround no point deduction occur"<<endl;
    cout << "6. The last player standing is crowned as King of Hearts!" << endl;
    cout << "====================================================" << endl;
   //cout << "\033[0m";
}



int main()

{
	
    clearScreen();
       system("color 3f");
    displayTitle();
    cout<<" Enter to See Rule:\n";
    _getch();
    displayRules();
    int pc=0;//playcount;
    string again;
    do
    {

        if(pc>0)
        {
            string c;
            cout<<"\n *To check Game rule press C:"
                <<"\n *Press P to Process Game :";
            cin>>c;
            if(c=="c"|| c=="C")
            {
            	   system("color 3f");
                displayRules();
                cout<<"\nEnter to continue ";
                _getch();
                _getch();
                clearScreen();
            }



        }



        system("color 3f");
        const int max_players = 4; // Maximum number of players
        int playernum = max_players; // Active player count
        string playern[max_players]; // Array for player names
        int pp[max_players] = {0};   // Array for player points (initialized to 0)
        int playerno[max_players];   // Array for player spins
        int ave;//target number for around
        string yes;//to control rounds
        int round = 1;



        system("color 3f");
        cout<<"Enter to continue :"<<endl;
        _getch();
        cout<<"\n===========================================================\n"<<endl;
        cout<<"Enter Player name :\n\n\n";
        // Input player names
        for (int i = 0; i < playernum; i++)
        {
            cout << "Enter Player " << i + 1 << " name: ";

            getline(cin,playern[i] );

        }


        //clearScreen();
        system("color 3f");
        cout<<"\n===========================================================\n\n"<<endl;

        string ready; //to ask player for to play
        cout<<" Are you ready : press R :";

        cin>>ready;

        while(ready!="r"&& ready!="R"&& ready !="T" && ready !="t")
        {
            cout<<"Press R or r if you are ready"
                <<"\n or To Retry game press T:";

            cin>>ready;

        }
        if(ready=="r"|| ready=="R")
        {

            do {
                clearScreen();
                system("color 3f");
                displayTitle();
              // cout << "\033[1;31m";
                cout<<"===================================="<<endl;
                cout<<"||            ROUND "<<round<<"             ||"<<endl;
                cout<<"===================================="<<endl;
               // cout << "\033[0m";

                // Display  points
                if(round==1)
                {
                    cout << "\n\Initial Points:" << endl;

                }
                else
                    cout << "\n\Current Points:" << endl;


                for (int i = 0; i < max_players; i++) 
				{
					if(pp[i]!=-999)
					{
					
                    cout << playern[i] << ": " <<"\t\t"<< pp[i] << " points" << endl;
                    }
                }

                cout<<"\n===========================================================\n\n"<<endl;
                
                //_getch();
                srand(time(NULL));
                int sum = 0;

                // Spin for each player
                cout<<" Player's Spin to get number "<<endl;
                 _getch();
                 cout<<"\n===========================================================\n\n"<<endl;
                for (int i = 0; i < max_players; i++) {



                    if (pp[i] != -999) 
					{
                        playerno[i] = 1 + rand() % 6;
                        cout<<"Press Enter to spin for player: ";
                        _getch();
                        cout<<endl << playern[i] << " spins and gets: \t\t" << playerno[i] << endl;

                        sum += playerno[i];
                    } else {
                        playerno[i] = 0;
                    }
                }

                // Calculate average
                int active_players = 0;
                for (int i = 0; i < max_players; i++) {
                    if (pp[i] != -999) active_players++;
                }
                
                cout<<"\n===========================================================\n\n"<<endl;
                cout<<"\n Press any key to see target number :\n";
                _getch();
                ave = (sum / active_players) + 1;
                cout << "\nTarget number \t\t: " << ave<<endl;

                int winners = 0;
                cout<<"\n===========================================================\n\n"<<endl;

                // Check who wins this round
                for (int i = 0; i < max_players; i++) {
                    if (pp[i] != -999 && playerno[i] == ave) {
                        cout<<" PLAYER " << playern[i] << " wins this round!" << endl;
                        winners++;
                    }
                }

                if (winners == 0) {
                    cout << " No winners in this round!" << endl;
                }

                if(winners>0)
                {
                    // Deduct points for non-winners
                    for (int i = 0; i < max_players; i++) {
                        if (pp[i] != -999 && playerno[i] != ave) {
                            pp[i]--;
                        }
                    }
                }
                cout<<"\n===========================================================\n\n"<<endl;

                // Display updated points
                cout << "\nUpdated Points:" << endl;
                for (int i = 0; i < max_players; i++) {
                    if (pp[i] != -999) {
                        cout <<""<< playern[i] << ": \t\t" << pp[i] << " points" << endl;


                    }
                }
                cout<<"\n===========================================================\n\n"<<endl;

                // Eliminate players with -6 points
                for (int i = 0; i < max_players; i++) {
                    if (pp[i] != -999 && pp[i] == -6) {
                        cout <<"\a"<< playern[i] << " is eliminated!\n" << endl;
                        pp[i] = -999; // Mark as eliminated
                        playernum--;
                    }
                }
                cout<<"\n Enter to Continue :\n";
                _getch();

                // Check if there's only one player left
                if (playernum == 1) {

                    for (int i = 0; i < max_players; i++) {
                        if (pp[i] != -999) {
                            clearScreen();
                            system("color 3f");
                            displayTitle();
                            cout<<"\a\a\a \t\t GAME OVER "<<endl;
                            // Clear the screen at the start
                            cout<<"============================================================="<<endl;
                            cout << "\n" << playern[i] << " is the final"
                                 << "\n winner and crowned as King of Hearts!\n" << endl;
                            cout<<"\n============================================================="<<endl;
                            break;
                        }
                    }
                    break;
                }

                // Ask user if they want to continue
                cout << "\nDo you want to play the next round? (Y/N): ";
                cin >> yes;

                // Validate user input (Only 'Y' or 'N' are allowed)
                while (yes != "y"&& yes != "Y" && yes != "n" && yes != "N") {
                    cout << "Invalid input! Please enter 'Y' or 'N': ";
                    cin >> yes;
                }

                round++;

            } while (yes == "Y" || yes == "y");


        }

        pc++;

        cout<<"\n\n*to play Again Press Y : "
            <<"\n*To Quit game press Q"<<endl;
        cin>>again;
        clearScreen();
           system("color 3f");
        displayTitle();

    } while(again=="y"|| again == "Y");

    clearScreen();
       system("color 3f");
    //the end
    displayTitle();
    cout<<"\n===========================================================\n\n"<<endl;
    cout<<" Thank you to play ."<<endl;
cout<<"\n===========================================================\n\n"<<endl;

    return 0;
}
