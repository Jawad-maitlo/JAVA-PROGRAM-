
public class Main {
    
    public static void main(String[] args) 
    {
        
        Game player = new Game();
       //loop control variable 
        boolean b= false;
        
        while(!b){
            player.takeUserInput();
            b=player.isNumberCorrect();
        }
        
    }
    
}