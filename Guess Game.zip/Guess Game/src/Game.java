import java.util.Random;
import java.util.Scanner;

public class Game {
    Random rand = new Random();
    Scanner sc = new Scanner(System.in);

    public int noToGuess;
    public int noOfguess=0;
    public int noGuess;
    
    public Game()
    {
        System.out.println("•|•|•|•|•|•|•|•|•|•|•|•|•");
        System.out.println("  Number Guessing Game");
        System.out.println("•|•|•|•|•|•|•|•|•|•|•|•|•");
        
        //Generating winning number 
        noToGuess=rand.nextInt(100);
    
    }
    
    
    
    public void takeUserInput()
    {
        System.out.print("Guess number 1-100:");
                noGuess=sc.nextInt();
                getDecrement();
    }
    
    
    
    
    public boolean isNumberCorrect(){
        if(noGuess==noToGuess)
        {
            System.out.printf("Congrat! You guess the number \n Number was %d \n in %d attempt",noToGuess,noOfguess);
            return true;
        }
        
        else if (noGuess+1==noToGuess)
        {
            System.out.println("very close");
        }
        else if (noGuess-1==noToGuess)
        {
            System.out.println("very close");
        }
        else if (noGuess>noToGuess)
        {
            System.out.println("To big");
        }
        else
        {
            System.out.println(" To small");
        }
        return false;
    }
    
    
    public void getDecrement()
    {
        noOfguess++;
    }
    
}